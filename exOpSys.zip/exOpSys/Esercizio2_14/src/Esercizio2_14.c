#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>
#include <dirent.h>
#include <pthread.h>

/*
 * *** esercizio B14***
il programma implementa la seguente funzione:

long calcola(long x);

questa funzione effettua il seguente calcolo:
y = x^4 - x^3 + x^2

il calcolo viene effettuato utilizzando 3 thread:
thread t1 effettua il calcolo x^4
thread t2 effettua il calcolo x^3
thread t3 effettua il calcolo x^2

la funziona 'calcola', crea i 3 thread, aspetta i risultati
e calcola e restituisce y.
 */



void* calcola1(void* arg){
	long  * x = (long*) arg;
	*x = *x * *x * *x * *x;
	printf("P1 %ld\n",*x);
	return (void*) x;

}
void* calcola2(void* arg){
	long  * x = (long*) arg;
	*x = *x * *x * *x;
	printf("P2 %ld\n",*x);
	return (void*) x;

}
void* calcola3(void* arg){
	long  * x = (long*) arg;
	*x = *x * *x;
	printf("P3 %ld\n",*x);
	return (void*) x;

}

long calcola(long x){
	pthread_t t1,t2,t3;
	long x1 = x, x2 = x, x3 = x;
	void **r= malloc(sizeof(int));
	pthread_create(&t1, NULL, calcola1, &x1);
	pthread_create(&t2, NULL, calcola2, &x2);
	pthread_create(&t3, NULL, calcola3, &x3);

	pthread_join(t1, r);
	printf("P1 %ld\n",**(long**)r);
	pthread_join(t2, r);
	printf("P2 %ld\n",**(long**)r);
	pthread_join(t3, r);
	printf("P3 %ld\n",**(long**)r);
	return x1 - x2 + x3;
}

int main(void) {
	printf("%ld\n", calcola(3));
	return EXIT_SUCCESS;
}
