# exOpSys
classroom exercises for 'Operating Systems' course


each directory contains a standalone example complete with .cproject and .project files, so that you can import the projects into Eclipse CDT IDE (currently using version 2020-12)

