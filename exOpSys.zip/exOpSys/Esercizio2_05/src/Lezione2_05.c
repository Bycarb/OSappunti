#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>


/*
 ***esercizio B5  'fork di 20 processi'  ***
Ogni processo può fare il fork di al più altri 2 processi
Avviare un totale di 20 processi, usando un contatore condiviso tra i processi
Usare un semaforo per regolare l'accesso concorrente al contatore da parte dei processi

(il contatore ha valore iniziale 0)
processo iniziale incrementa crea due processi P1 e P2;
P1 crea due processi P3 e P4;
P2 crea due processi P5 e P6;
P3 crea due process....
(prima di ogni singolo fork(), viene controllato il valore del contatore (deve essere < 20) ed incrementato il contatore condiviso)
[soluzione: https://moodle2.units.it/mod/resource/view.php?id=226879]
 */

char* sem_name = "/sem1";
sem_t* sem;
int* counter;


int main() {

	sem_unlink(sem_name);
	sem = sem_open(sem_name, O_CREAT, S_IRUSR | S_IWUSR, 1 );
	counter = mmap(NULL, sizeof(int), PROT_WRITE | PROT_READ, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
		if(counter == MAP_FAILED){
			perror("mmap");exit(1);
		}

	*counter = 1;
	int fork_counter = 0;
	printf("Process num %d started, %d  %d\n", *counter, getpid(), getppid());

	while(1){
		pid_t pid = -1;
		if (fork_counter == 0) {
			if(sem_wait(sem) == -1){// aspetto che si liberi il semaforo
				perror("sem_wait"); exit(1);
			}
		}
		if(*counter < 20){
			(*counter) ++;
			fork_counter ++;
			pid = fork();
			if(pid == -1){
				perror("fork");exit(1);
			}else if(pid == 0){
				printf("Process num %d started, %d  %d\n", *counter, getpid(), getppid());
				fork_counter = 0;
			}else{
				// il padre rilascia il mutex
				if(sem_post(sem) == -1){
					perror("sem_post"); exit(1);
				}
			}
		}

		if(*counter == 20 || fork_counter == 2){
				break;
			}
	}

	int wait_counter = 0;
	while (wait(NULL) != -1)
			wait_counter++;

	//printf("bye counter = %d, pid=%d, number of child processes: %d\n", *counter,  getpid(), wait_counter);

	return EXIT_SUCCESS;
}
