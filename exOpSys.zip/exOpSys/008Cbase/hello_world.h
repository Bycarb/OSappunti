/*
 * hello_world.h
 *
 *  Created on: Mar 18, 2019
 *      Author: marco
 */

#ifndef HELLO_WORLD_H_
#define HELLO_WORLD_H_


void hello_world(void);

void hello_world_string_multi_line() ;

void hello_world_multi_printf();

hello_world_printf(); // permesso ma provoca un warning; il compilatore lo considera come: int hello_world_printf()

#endif /* HELLO_WORLD_H_ */
