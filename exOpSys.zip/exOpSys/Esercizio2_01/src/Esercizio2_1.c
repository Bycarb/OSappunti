#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>


/*
 ***esercizio B1  'rimpiazza contatore con valore in file' ***
il programma riceve via parametri a riga di comando il nome del file da processare

modificare il file in questo modo:
ogni volta che compare la stringa di caratteri "*CONTATORE*" questa va sostituita con numero intero fornito da un contatore
che si incrementa ad ogni sostituzione (il contatore parte da zero).

esempio:

Lorem ipsum at *CONTATORE* donec urna aenean ornare hac condimentum nulla, amet aliquet dapibus orci cursus semper nostra dictum, lorem imperdiet interdum ad sit dui ut  litora.
Tortor lacus ut velit ad enim *CONTATORE*scelerisque viverra pellentesque, curae  ut leo bibendum turpis convallis risus urna ad, aenean mattis dapibus
pretium luctus vestibulum *CONTATORE*dictum ut tempus conubia sit donec lobortis
conubia pellentesque venenatis enim. Posuere primis sagittis molestie*CONTATORE* ut dapibus, molestie mauris quis  rutrum ma*CONTATORE*ecenas,
arcu phasellus nullam nisl metus dapibus elementum  tempus tristique leo risus sollicitudin.

(in questo esempio, la stringa di caratteri *CONTATORE* compare 5 volte)


il file viene sovrascritto e diventerà:

Lorem ipsum at 0 donec urna aenean ornare hac condimentum nulla, amet aliquet dapibus orci cursus semper nostra dictum, lorem imperdiet interdum ad sit dui ut  litora.
Tortor lacus ut velit ad enim 1scelerisque viverra pellentesque, curae  ut leo bibendum turpis convallis risus urna ad, aenean mattis dapibus
pretium luctus vestibulum 2dictum ut tempus conubia sit donec lobortis
conubia pellentesque venenatis enim.
Posuere primis sagittis molestie3 ut dapibus, molestie mauris quis  rutrum ma4ecenas, arcu phasellus nullam nisl metus dapibus elementum tempus tristique leo risus sollicitudin.
 */

int openfile(char * filename){
	int fd = open(filename, O_RDWR);
		if (fd == -1) {
			perror("open()");
			exit(EXIT_FAILURE);
		}
	return fd;
}

char * change_first_word_array (char *sentence, char *find, char *replace, int *cnt)
{
    char *dest = malloc (strlen(sentence)-strlen(find)+strlen(replace)+1);
    char *destptr = dest;
    int found = 0;

    *destptr = 0;

    while (*sentence)
    {
        if (!strncmp (sentence, find, strlen(find)) && !found)
        {
            strcat (destptr, replace);
            sentence += strlen(find);
            destptr += strlen(replace);
            found = 1;
        } else
        {
            *destptr = *sentence;
            destptr++;
            sentence++;
        }
    }
    *destptr = 0;
    *cnt = *cnt+found;

    return dest;
}

void change_word_with_counter(char * filename, char * word){
	struct stat statbuf;
	off_t file_len=0;
	char * text;
	int cnt=0;
	char cnt_string[10] = {0};
	int bytes_read;

	int fd = open(filename, O_RDONLY);
			if (fd == -1) {
				perror("open()");
				exit(EXIT_FAILURE);
			}

	if( fstat(fd, &statbuf)!= 0 ) {
		perror("fstat\n");
		exit(1);
	}
	file_len = statbuf.st_size;
	if ( ( text = malloc(file_len * sizeof(char)) ) == NULL ){
		perror("malloc");
		exit(1);
	}
	bytes_read = read(fd, text, file_len);
		if(bytes_read <= 0){
			perror("Error reading file");
			exit(1);
		}

	close(fd);

	sprintf(cnt_string,"%d", cnt);
	int cnt2 = 0;
	while(cnt == cnt2){
		text = change_first_word_array(text, word, cnt_string, &cnt);
		sprintf(cnt_string,"%d", cnt);
		cnt2++;
	}

	printf("%s", text);

	fd = open(filename, O_TRUNC | O_WRONLY,
			  S_IRUSR | S_IWUSR);
				if (fd == -1) {
					perror("open()");
					exit(EXIT_FAILURE);
				}

	bytes_read = write(fd, text, strlen(text));
		if(bytes_read <= 0){
			perror("write");
			exit(1);
		}
}

int main(void) {
	int fd;
	char * filename = "prova.txt";
	char * word = "*CONTATORE*";

	change_word_with_counter(filename, word);

	return EXIT_SUCCESS;
}
