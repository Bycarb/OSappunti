/*
 ***esercizio B3  'zip 2'  ***
Scrivere un programma che prende come parametro un nome di file da creare (nome_file)
Legge i dati da stdin e li fa comprimere dall’utility zip nell’archivio compresso nome_file
Quando l’utente digita Ctrl-C, il programma termina il processo zip, e mostra la dimensione dell’archivio compresso (ovvero lancia il comando ls -l nome_file.zip), poi termina.
 Esempio di comando bash che comprime la stringa ‘foo bar’ immagazzinandola in un un archivio compresso chiamato nome_file.zip (l’estensione .zip viene aggiunta automaticamente)
echo 'foo bar' | zip -q nome_file -
 */


#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>

#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>


int pipefd[2];
char* filename;


__off_t get_file_size(char * filename) {

	struct stat sb;
	int res;

	res = stat(filename, &sb);

	if (res == -1) {
		perror("fstat()");
		return -1;
	}

    return sb.st_size;
}

static void sig_handler(int sig) {
	// NON è sicuro chiamare printf da un signal handler!
	// printf non è async-signal-safe (vedere Kerrisk sezione 21.1.2)
	// printf è usato qui solo a scopo diagnostico/didattico

	printf("[parent] ho ricevuto il segnale %d\n", sig);


	// termino il processo figlio chiudendo
	// l'estremità di scrittura della pipe
	// di conseguenza all'estremità di lettura della pipe
	// arriverà EOF
	if (close(pipefd[1]) == -1) {
		perror("close");
	}

	printf("[signal handler] bye\n");

	// aspetto la conclusione del processo figlio (zip)
	if (wait(NULL) == -1) {
		perror("wait");
	} else {
		// mostro la dimensione dell'archivio
		__off_t filesize = get_file_size(filename);

		printf("dimensione archivio: %ld bytes\n", filesize);
	}

	exit(0);

}

extern char **environ;
pid_t new_session_id;

int main(int argc, char*argv[]) {
	if (argc != 2){
		perror("Wrong input parameters");
		exit(1);
	}
	filename = argv[1];
	char* zip_path = "/usr/bin/zip";
	char* zip_argv[] = {zip_path, "-q", filename, "-", NULL};

	int c=0; char ch;

	if (signal(SIGINT, sig_handler) == SIG_ERR) {
			perror("signal");
		}

	int pipefd[2];
	if(pipe(pipefd)){
		perror("pipe");
		exit(1);
	}

	switch(fork()){
	case -1:
		perror("fork");
		exit(1);
		break;
	case 0:
		//figliuolo invoca zip
		if(close(pipefd[1])){
			perror("close");
			exit(1);
		}
		dup2(0,pipefd[0]);

		new_session_id = setsid();

		execve(zip_path, zip_argv, environ);
		perror("execve");
		exit(1);
		break;
	default :
		if(close(pipefd[0])){
			perror("close");
			exit(1);
		}
		dup2(1,pipefd[1]);

		while ((c = getchar()) != EOF) {
			ch = (char) c;
			if (write(1, &ch, sizeof(ch)) == -1) {
				perror("write");
				exit(1);
			}
		}

		if (close(1)){
			perror("close");
			exit(1);
		}

		break;
	}


	return EXIT_SUCCESS;
}
