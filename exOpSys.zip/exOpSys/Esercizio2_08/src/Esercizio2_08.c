#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>


/*
 * ***esercizio B8***
Il processo principale origina due processi figli A e B
Il processo A «produce» un risultato: RA
Il processo B «produce» un risultato: RB
Il processo principale aspetta la conclusione dei due processi A e B; quando entrambi hanno concluso l’esecuzione,
concatena RA e RB e scrive il risultato sull’output.

RA e RB sono stringhe di caratteri
 */


int main(void) {
	int pipe1[2];
	int pipe2[2];
	char * result;
	pid_t pid1,pid2;

	result = calloc( 100, sizeof(char));
		if(result == NULL){perror("malloc"); exit(1);};

	if( pipe(pipe1) )	{perror("pipe");exit(1);}
	if( pipe(pipe2) )	{perror("pipe");exit(1);}

	pid1 = fork();
	if(pid1 == -1){
		perror("fork");exit(1);
	}else if(pid1 == 0){
		close(pipe1[0]);
		char * message = "Message 1 \n";
		write(pipe1[1],message, strlen(message));
		close(pipe1[1]);
		exit(0);
	}else{
		pid2 = fork();
		if(pid2 == -1){
			perror("fork");exit(1);
		}else if(pid2 == 0){
			close(pipe2[0]);
			char * message = "Message 2 \n";
			write(pipe2[1],message, strlen(message));
			close(pipe2[1]);
			exit(0);
		}else{
			int res;

			close(pipe1[1]);
			close(pipe2[1]);
			wait(&res);
			wait(&res);
			char * buffer = malloc(100 * sizeof(char));
			read(pipe1[0], buffer, 100);
			strcat(result, buffer);
			read(pipe2[0], buffer, 100);
			strcat(result, buffer);
			printf("%s", result);
		}
	}

	return EXIT_SUCCESS;
}
