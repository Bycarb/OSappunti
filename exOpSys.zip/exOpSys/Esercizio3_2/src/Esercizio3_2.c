#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>

#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/random.h>

/*
 * *** esercizio C02 *** produttore-consumatore di random cookies
[difficoltà: medio-alta]

un "cookie" è una stringa di caratteri di lunghezza 32, composto da caratteri casuali.
usare la system call getrandom (man 2 getrandom) per ottenere i caratteri casuali.

sono definite le variabili globali:
char buffer[32];
int cookie_counter;

#define N 1024

il programma ha un thread t1 che fa quanto segue:
(i seguenti passaggi sono iterati per N volte; poi fa terminare il programma)
- produce un cookie
- lo scrive in buffer
- "segnala" al thread t2 di "consumare" il cookie
- quanto t2 "ha consumato" il cookie, continua

il thread t2 fa quanto segue:
(i seguenti passaggi sono iterati)
- ogni volta che t1 lo avvisa che è pronto un cookie, incrementa cookie_counter
- (opzionale) accoda cookie al file "log.dat"
- "segnala" al thread t1 di procedere

[la soluzione è un "produttore-consumatore" con buffer finito, Little Boof of Semaphores, pag. 55-65]
[soluzione: https://moodle2.units.it/mod/resource/view.php?id=227319]
 */

char buffer[32];
int cookie_counter;

#define N 1024

sem_t mutex;
sem_t items;
sem_t spaces;

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

void * thread1(void * arg){
	char cookie[32];

	for(int i=0; i<N; i++){
		if ( getrandom(cookie, sizeof(cookie), 0) < sizeof(cookie)){
			printf("problemi con getrandom\n");
			exit(1);
		}

		sem_wait(&spaces);
		sem_wait(&mutex);

		memcpy(buffer, cookie, sizeof(cookie));
		printf("[producer] prodotto %d\n", i);

		sem_post(&mutex);
		sem_post(&items);
	}
	return NULL;
}

void * thread2(void* arg){
	for(int i = 0; i<N; i++){
		sem_wait(&items);
		sem_wait(&mutex);

		printf("[consumer] ricevuto %d\n", i);

		sem_post(&mutex);
		sem_post(&spaces);
	}
	return NULL;
}


int main(void) {
	pthread_t t1,t2;

	sem_init(&mutex, 0, 1);
	sem_init(&items, 0, 0);
	sem_init(&spaces, 0, 1);

	pthread_create(&t1, NULL, thread1, NULL);
	pthread_create(&t2, NULL, thread2, NULL);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);

	printf("*****\n");

	return EXIT_SUCCESS;
}
