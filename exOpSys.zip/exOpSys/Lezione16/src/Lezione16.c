#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>

// esercizio c7
// uso semaforo con nome

#define N 1000
char * filename  = "prova.txt";
sem_t semaphore;


int main(void) {
	if(sem_unlink(semaphore_name, O_CREAT, 0))


	return EXIT_SUCCESS;
}
