#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>
#include <dirent.h>

/*
 * ***esercizio B12***
il programma riceve come parametro a riga di comando il percorso di una directory
su cui farà la seguente verifica:

sulla directory fornita, va a scorrere tutti i file della directory e sui soli file che appartengono
allo stesso effective user del processo corrente, fa la seguente verifica sui permessi per il "resto del mondo":
se "il resto del mondo" ha permessi di scrittura, scrive su stdout il percorso completo del file (usare realpath).
 */

int main(void) {
	char * path = "/home/andrea/Desktop/Provac";
	DIR* dir = opendir(path);
	struct dirent* dirdetails;
	struct stat * fileStat = malloc(sizeof(struct stat));
	char * filepath = calloc(256, sizeof(char));
	while( (dirdetails = readdir(dir)) != NULL){
		sprintf(filepath,"%s/%s", path, dirdetails->d_name);
		printf("%s\n", filepath);
		stat(filepath, fileStat);
		printf("File Permissions: \t");
		    //printf( (S_ISDIR(fileStat.st_mode)) ? "d" : "-");
		    printf( (fileStat->st_mode & S_IRUSR) ? "r" : "-"); //current user
		    printf( (fileStat->st_mode & S_IWUSR) ? "w" : "-");
		    printf( (fileStat->st_mode & S_IXUSR) ? "x" : "-");
		    printf( (fileStat->st_mode & S_IRGRP) ? "r" : "-"); //usergroup
		    printf( (fileStat->st_mode & S_IWGRP) ? "w" : "-");
		    printf( (fileStat->st_mode & S_IXGRP) ? "x" : "-");
		    printf( (fileStat->st_mode & S_IROTH) ? "r" : "-"); //resto del mondo
		    printf( (fileStat->st_mode & S_IWOTH) ? "w" : "-");
		    printf( (fileStat->st_mode & S_IXOTH) ? "x" : "-");
		    printf("\n\n");
		if(fileStat->st_mode & S_IWOTH){
			printf("%s\n\n", realpath(filepath, NULL));
		}
	}


	return EXIT_SUCCESS;
}
