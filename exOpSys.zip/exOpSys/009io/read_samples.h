#ifndef READ_SAMPLES_H_
#define READ_SAMPLES_H_

int read_2_ints();


void test_strlen();

#endif /* READ_SAMPLES_H_ */
