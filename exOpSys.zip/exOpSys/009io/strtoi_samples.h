#ifndef STRTOI_SAMPLES_H_
#define STRTOI_SAMPLES_H_

void strtoi_samples(void);

#endif /* STRTOI_SAMPLES_H_ */
