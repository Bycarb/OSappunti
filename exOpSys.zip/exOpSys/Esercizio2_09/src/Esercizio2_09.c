#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>

/*
 ***esercizio B9***
partire dall'esempio: https://github.com/marcotessarotto/pafft
(è un programma che registra audio dal microfono del computer, calcola la fft e mostra quella che dovrebbe essere la frequenza con ampiezza maggiore;
bisognerebbe aggiungere un filtro per migliorare il risultato)

nota: per estrarre tramite git il codice sorgente dell'esempio sopra, usare il comando:

git clone --recurse-submodules https://github.com/marcotessarotto/pafft


Scrivere dei programmi in modo tale che un comando di questo tipo sia analogo a pafft:
recordaudio | do_fft | lookup_max_freq
recordaudio: legge da «audio in» e scrive lo stream su stdout
do_fft: legge da stdin i dati nel dominio del tempo, calcola la fft e la scrive su stdout
lookup_max_freq : legge lo spettro e cerca la frequenza per cui si ha il massimo assoluto; scrive il risultato su stdout
 */

int main(void) {

	return EXIT_SUCCESS;
}
