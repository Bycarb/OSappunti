/*
 * my_header.h
 *
 *  Created on: Jan 29, 2020
 *      Author: marco
 */

#ifndef MY_HEADER_H_
#define MY_HEADER_H_

// DICHIARAZIONI di funzioni

void caratteri_ascii(void);
void hello_world_string_multi_line();
void hello_world_multi_printf();



#endif /* MY_HEADER_H_ */
