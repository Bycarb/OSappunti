#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>

/*
 ***esercizio B7  'ricerca in file con più processi'  ***
Il programma prende tre parametri: un nome di file,
									un numero intero > 0 (M),
									una stringa di caratteri S da cercare nel file
All’interno di un file passato come argomento al programma, questo crea M processi
Ciascun processo cerca nel pezzo di file assegnato la stringa S
	(se la trova, scrive a video l’offset della stringa nel file)
Ciascun processo opera su un pezzo del file di dimensione pari a file_size/M + K
	(con K >=0 tale che se la stringa S è a cavallo di due pezzi contigui, S venga trovata)
 */

unsigned long get_file_size(char * fname) {

	struct stat st;

	int res = stat(fname, &st);

	if (res == -1) {
		perror("stat error");
		return -1;
	} else
		return st.st_size;

}

int main(void) {
	//TODO prendere da riga di comando
	char * filename = "prova.txt";
	int M = 5;
	char * S = "testo";
	int K = strlen(S) - 1;
	int fd;
	unsigned long file_size = get_file_size(filename);;
	char * map;
	pid_t pid;
	int chunk_size = file_size/M;

	fd = open(filename, O_RDONLY);
		if (fd == -1) {
			perror("open");
			exit(1);
		}

	map = mmap(NULL, file_size, PROT_READ, MAP_SHARED, fd, 0);
		if (map == -1) {
				perror("mmap");
				exit(1);
			}

	for(int i = 0; i<M; i++){
		pid = fork();

		if(pid == -1){
			perror("fork");
			exit(1);
		}else if(pid == 0){
			for(int j = 0; j< (file_size/M) ; j++){
				int found = 1;
				for(int k = 0; k<strlen(S); k++){
					if( !( map[i*chunk_size +j +k] == S[k] ) ){
						found = 0;
						break;
					}
				}
				if (found){
					printf("Found in position %d\n", i*chunk_size +j);
				}
			}
			printf("Killing child %d\n", getpid());
			exit(0);

		}else{

		}
	}



	return EXIT_SUCCESS;
}
