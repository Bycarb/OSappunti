/*
 ****esercizio B4  'due processi'  ***
Due processi: A (parent) e B (child), condividono un file aperto in modalità scrittura
(e quindi anche l'offset del file).
il processo A fa l'append di una riga di testo al file; dorme un secondo; comunica al processo B di continuare.
Il processo A aspetta.

il processo B, a sua volta, fa l'append di una riga di testo allo stesso file; dorme un secondo;
comunica al processo A di continuare.

Il processo B aspetta.
Quando il processo A ha scritto la centesima riga ,manda un segnale di terminazione al processo B,
aspetta che B termini e poi termina anche A.
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>

#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>

int N = 5;

static void sig_handler_parent(int signum){

}

static void sig_handler_child(int signum){

}

static void sig_term_child(){
	printf("child terminated\n");
	exit(0);
}

int main(void) {
	pid_t this_pid, other_pid;
	int status = 0;
	char* buffer = calloc(50, sizeof(char));
	int fd = open("Prova.txt", O_CREAT | O_TRUNC | O_WRONLY, S_IRUSR | S_IWUSR );
		if (fd == -1) {
			perror("open()");
			exit(EXIT_FAILURE);
		}

	switch( other_pid = fork()){
		case -1: perror("fork");exit(1);
		case 0 :
			//child

			this_pid = getpid();
			other_pid = getppid();

			if(signal(40, sig_handler_child) == SIG_ERR){
				perror("signal"); exit(1);
			}
			if(signal(SIGTERM, sig_term_child) == SIG_ERR){
				perror("signal"); exit(1);
			}

			for(int i = 0; i<N; i++){
				pause();
				printf("CHILD: Line number %d\n", i+1);
				sprintf(buffer,"CHILD: Line number %d\n", i+1);
				write(fd, buffer, strlen(buffer));
				sleep(1);
				if (kill(other_pid, 40)){
					perror("Signal");exit(1);
				}
			}

			break;
		default:
			//parent
			this_pid = getpid();

			if(signal(40, sig_handler_parent) == SIG_ERR){
				perror("signal"); exit(1);
			}

			for(int i = 0; i<N; i++){
				printf("PARENT: Line number %d\n", i+1);
				sprintf(buffer, "PARENT: Line number %d\n", i+1);
				write(fd, buffer, strlen(buffer));
				sleep(1);
				if (kill(other_pid, 40)){
					perror("Signal");exit(1);
				}
				pause();
			}

			if (kill(other_pid, SIGTERM)){
				perror("Signal");exit(1);
			}
			wait(&status);
			if (status){
				perror("wait");exit(1);
			}else printf("PARENT: reached end\n");

			break;
	}


	return EXIT_SUCCESS;
}
