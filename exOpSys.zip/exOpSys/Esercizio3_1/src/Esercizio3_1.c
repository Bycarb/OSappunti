#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>
#include <dirent.h>
#include <pthread.h>


/*
 * *** esercizio C01 *** produttore di cookies a velocità variabile
[difficoltà: medio]

il programma ha un contatore che parte da zero.
è definita una variabile globale che si chiama machine_state; machine_state ha due stati possibili: 0 ed 1.
se machine_state == 0, il programma non produce cookies; se machine_state == 1, il produce cookies.

(quando machine_state == 1) il programma scrive su stdout il valore corrente del contatore,
incrementa il contatore e poi dorme per "dt" millisecondi.
all'avvio del programm, dt = 1000.
deve valere sempre la condizione: dt > 0
deve valere sempre la condizione: dt <= 10000

ogni volta che il programma riceve SIGUSR1, "dt" viene decrementato di 100.
ogni volta che il programma riceve SIGUSR2, "dt" viene incrementato di 100.
ogni volta che il programma riceve SIGTERM, machine_state cambia stato (
se machine_state == 0 allora machine_state = 1 etc)
 */

int machine_state = 1;
long dt = 1000;

void hadler_usr1(int sig){
	dt = dt>100 ? dt-100 : dt;
}
void hadler_usr2(int sig){
	dt = dt<9900 ? dt+100 : dt;
}
void hadler_term(int sig){
	machine_state = !machine_state;
}


int main(void) {
	int cnt = 0;
	struct timespec sleep_time;
	sleep_time.tv_nsec = dt % 1000;
	sleep_time.tv_sec = dt / 1000;

	if(signal(SIGUSR1, hadler_usr1) == SIG_ERR){
		perror("signal");exit(1);
	}
	if(signal(SIGUSR2, hadler_usr2) == SIG_ERR){
			perror("signal");exit(1);
		}
	if(signal(SIGTERM, hadler_term) == SIG_ERR){
			perror("signal");exit(1);
		}

	while(1){
		if(machine_state == 1){
			printf("[PID:%d]\tCounter = %d\n", getpid(), cnt++);
		}
		sleep_time.tv_nsec = dt % 1000;
		sleep_time.tv_sec = dt / 1000;
		nanosleep(&sleep_time, NULL);
	}
	return EXIT_SUCCESS;
}
