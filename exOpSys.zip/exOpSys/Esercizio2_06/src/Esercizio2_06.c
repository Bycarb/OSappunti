#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <sys/mman.h>
#include <time.h>
#include <errno.h>


/*
 ***esercizio B6  'scrittura su file da parte di più processi'  ***
Scrivere un programma che:
crea un file di dimensione N bytes nella cartella dei file temporanei /tmp/
#define N (256*16)
#define M 16

il programma crea M processi: il processo i-mo scrive il carattere ‘A’+i
in una parte del file di dimensione N / M bytes, con offset pari a i * N/M.
 */


#define N (256*16)
#define M 16


int main(void) {

	int fd;
	char * map;
	char * filename = "prova.txt";
	pid_t pid;

	fd = open(filename, O_CREAT | O_TRUNC | O_RDWR, S_IRUSR | S_IWUSR);
		if (fd == -1) {
			perror("open");
			exit(1);
		}

	if( ftruncate(fd, N) == -1) {
		perror("ftruncate");
		exit(1);
	}

	map = mmap(NULL, N, PROT_WRITE | PROT_READ, MAP_SHARED, fd, 0);

	if (close(fd) == -1) {
		perror("close");
		exit(1);
	}

	for(int i = 0; i<M; i++){
		pid = fork();
		if(pid == -1){
			perror("fork");
			exit(1);
		}
		if(pid == 0){
			int offset = i*N/M;
			int dim = N/M;

			memset (&map[offset], 'A'+i, dim);
			exit(0);
		}
	}

	while (wait(NULL) != -1) ;

	printf("bye\n");

	return EXIT_SUCCESS;
}
