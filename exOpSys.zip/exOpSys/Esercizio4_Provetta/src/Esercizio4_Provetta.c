#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <fcntl.h>
#include <string.h>

#include <signal.h>

#include <semaphore.h>
#include <sys/mman.h>
#include <pthread.h>


#define N 16
#define P 20

char * sem_avvio_lavoro_name = "/sem_avvio_lavoro";
char * sem_dati_pronti_name = "/sem_dati_pronti";

char * file_name = "prova.dat";

sem_t * sem_avvio_lavoro;
sem_t * sem_dati_pronti;

int * map1; // dimensione memory map: sizeof(int)
char * map2; // dimensione memory map: N

int val;


void create_semaphores(){
	//Semaforo 1
	if (sem_unlink(sem_avvio_lavoro_name) == -1) {
		printf("Non e` stato necessario sovrascrivere il semaforo avvio\n");
	}
	sem_avvio_lavoro = sem_open(sem_avvio_lavoro_name, O_CREAT, 0600, 0);
	if (sem_avvio_lavoro == SEM_FAILED) {
		perror("sem_open");
		exit(1);
	}

	//Semaforo 2
	if (sem_unlink(sem_dati_pronti_name) == -1) {
		printf("Non e` stato necessario sovrascrivere il semaforo dati\n");
	}
	sem_dati_pronti = sem_open(sem_dati_pronti_name, O_CREAT, 0600, 0);
	if (sem_dati_pronti == SEM_FAILED) {
		perror("sem_open");
		exit(1);
	}

	printf("Creati i 2 semafori\n");
}

void create_maps(){

	map1 = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1,0 );
		if (map1 == MAP_FAILED) {
			perror("mmap");
			exit(1);
		}
	map2 = mmap(NULL, N * sizeof(char), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1,0 );
		if (map2 == MAP_FAILED) {
			perror("mmap");
			exit(1);
		}
		printf("Create le mmaps\n");
}

int open_file(){
	int fd = open(file_name,
					  O_CREAT | O_TRUNC | O_WRONLY,
					  S_IRUSR | S_IWUSR);

		if (fd == -1) {
			perror("open()"); exit(1);
		}
	printf("Creato il file %s, con fd = %d\n\n\n", file_name, fd);

	return fd;
}

void * thread_function(void * arg){
	//assegna il valore ('A' + val) ad ogni char di 'map2'
	for(int i = 0; i<N; i++){
		map2[i] = 'A'+ val;
	}
	return NULL;
}

static void sig_handler(int sig){
	// uso write invece di printf per il signal handler in quanto async-signal-safe
	char* msg = "[Child] Ricevuto segnale terminazione\n";
	if ( write(STDOUT_FILENO, msg, strlen(msg)) == -1){
		perror("write");exit(1);
	}
	exit(0);
}

void parent_process(int child_pid){
	int fd;
	fd = open_file();

	for (int i = 0; i < P; i++) { // <<==== attenzione: P, non N
	     //1 - scrive il valore i nella memory map 'map1'
		*map1 = i;
	     //2 - incrementa il semaforo '/sem_avvio_lavoro'
		    //per comunicare al processo figlio che deve preparare un blocco di dati di N bytes
		if (sem_post(sem_avvio_lavoro) != 0) {
			perror("sem_post");
			exit(1);
		}
	     //3 - aspetta, al semaforo '/sem_dati_pronti', che arrivino i dati preparati dal processo figlio
		if (sem_wait(sem_dati_pronti) != 0) {
			perror("sem_wait");
			exit(1);
		}
	     //4 - scrive nel file i dati ricevuti (sono N bytes contenuti nella memory map 'map2')
		int res = write(fd, map2, N);
			if (res == -1) {
				perror("write()");
				exit(EXIT_FAILURE);
			}
		printf("[Parent]Scritti su file %d bytes, valore %c\n\n", res, map2[0]);
	}

	if (close(fd) == -1) {
		perror("close"); exit(1);
	}
	//il processo padre fa terminare il processo figlio con un segnale a scelta.
	printf("\n[Parent] Termino processo figlio...\n");
	if ( kill(child_pid, SIGUSR1) == -1 ){
		perror("kill\n"); exit(1);
	}

}

void child_process(){
	//il processo padre fa terminare il processo figlio con un segnale a scelta.
	if (signal(SIGUSR1, sig_handler) == SIG_ERR) {
			perror("signal");
		}

	while (1) {
		//1 - va in attesa sul semaforo (lo decrementa) '/sem_avvio_lavoro' (semaforo creato dal processo padre)
		if (sem_wait(sem_avvio_lavoro) != 0) {
			perror("sem_wait");
			exit(1);
		}

		//2 - legge il valore (di tipo int) dalla memory map 'map1' e lo scrive in una variabile 'val'
		val = *map1;

		//3 - crea un thread che assegna il valore ('A' + val) ad ogni char di 'map2'
		pthread_t t1;
		int s = pthread_create(&t1, NULL, thread_function, NULL);
			if (s != 0) {
				perror("pthread_create");
				exit(1);
			}

		//3 - aspetta la conclusione del thread
		s = pthread_join(t1, NULL);
			if (s != 0) {
				perror("pthread_join");
				exit(1);
			}

		//4 - i dati nella memory map 'map2' sono pronti
		printf("[Child] La stringa numero %d e` pronta\n", val+1);

		//5 - incrementa un semaforo chiamato '/sem_dati_pronti'
		if (sem_post(sem_dati_pronti) != 0) {
			perror("sem_post");
			exit(1);
		}
	}
}

int main(void) {
	int res;

	create_semaphores();
	create_maps();

	res = fork();
	if(res == -1){
		perror("fork\n"); exit(1);
	}else if(res == 0){
		//Child
		child_process();
	}else{
		//Parent
		parent_process(res);
	}

	return EXIT_SUCCESS;
}
